export function log(msg, ...args) {
    console.log(`afk-ready-check | ${msg}`, ...args);
}
